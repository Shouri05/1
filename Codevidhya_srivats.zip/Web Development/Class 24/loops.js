const c=5;

for(var i=0; i<=5;i++){
    console.log("I love javascript")
}
 var s={
    Age: 3,
    Name: "Sriv",
    LastName:"B"
 }
 for(var x in s )
 {
    txt+=s[x]

 document.getelementbyid